#ifndef _LED_H
#define _LED_H
void LED_Init(void);
#define LED0 PDout(1) 
#define LED1 PEout(5)


#endif


