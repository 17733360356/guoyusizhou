#ifndef _BEEP_H
#define _BEEP_H

void BEEP_Init(void);
#define BEEP PBout(8)

#endif

